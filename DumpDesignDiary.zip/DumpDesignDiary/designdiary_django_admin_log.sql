-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: designdiary
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2025-03-19 21:41:29.409754','1','Articles object (1)',1,'[{\"added\": {}}]',7,1),(2,'2025-03-20 18:27:20.165630','1','coffee mug',2,'[]',7,1),(3,'2025-03-20 18:27:59.455113','2','coffe with table',1,'[{\"added\": {}}]',7,1),(4,'2025-03-20 18:42:45.109443','3','pakachu',1,'[{\"added\": {}}]',7,1),(5,'2025-03-20 19:01:45.094713','4','wallpaer',1,'[{\"added\": {}}]',7,1),(6,'2025-03-21 09:22:02.834965','5','pr1',1,'[{\"added\": {}}]',7,1),(7,'2025-03-21 09:23:25.855194','6','p23',1,'[{\"added\": {}}]',7,1),(8,'2025-03-21 16:00:10.094648','2','coffe with table',3,'',7,1),(9,'2025-03-21 16:00:10.095733','1','coffee mug',3,'',7,1),(10,'2025-03-21 16:00:10.095733','6','p23',3,'',7,1),(11,'2025-03-21 16:00:10.095733','3','pakachu',3,'',7,1),(12,'2025-03-21 16:00:10.095733','5','pr1',3,'',7,1),(13,'2025-03-21 16:00:10.095733','4','wallpaer',3,'',7,1),(14,'2025-03-21 16:01:31.093957','7','Bouquet keychain',1,'[{\"added\": {}}]',7,1),(15,'2025-03-21 16:33:39.453937','8','Sunflower Keychain',1,'[{\"added\": {}}]',7,1),(16,'2025-03-21 16:34:02.827513','9','Pink',1,'[{\"added\": {}}]',7,1),(17,'2025-03-21 16:34:19.807869','10','Yellow',1,'[{\"added\": {}}]',7,1),(18,'2025-03-21 16:34:38.818173','11','Baby pink',1,'[{\"added\": {}}]',7,1),(19,'2025-03-21 16:34:53.517031','12','Green',1,'[{\"added\": {}}]',7,1),(20,'2025-03-21 16:59:05.335987','8','Sunflower Keychain',2,'[{\"changed\": {\"fields\": [\"Type\"]}}]',7,1),(21,'2025-03-21 17:05:52.799262','7','Bouquet keychain',2,'[{\"changed\": {\"fields\": [\"Type\"]}}]',7,1),(22,'2025-03-21 17:08:04.340335','13','Ankle smth',1,'[{\"added\": {}}]',7,1),(23,'2025-03-21 17:08:23.435591','14','Crochet pouches',1,'[{\"added\": {}}]',7,1),(24,'2025-03-21 17:08:37.698170','15','Gray',1,'[{\"added\": {}}]',7,1),(25,'2025-03-21 17:08:57.075721','16','Keychain',1,'[{\"added\": {}}]',7,1),(26,'2025-03-21 17:09:13.031329','17','Keychain',1,'[{\"added\": {}}]',7,1),(27,'2025-03-21 17:09:48.443834','18','Long green',1,'[{\"added\": {}}]',7,1),(28,'2025-03-21 17:10:09.024880','19','1',1,'[{\"added\": {}}]',7,1),(29,'2025-03-21 17:10:19.429128','20','2',1,'[{\"added\": {}}]',7,1),(30,'2025-03-21 17:10:30.260594','21','3',1,'[{\"added\": {}}]',7,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-28 23:41:05
